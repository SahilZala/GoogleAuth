package com.sahil.googleauth;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MediaController;
import android.widget.VideoView;

public class VideoPlayer extends AppCompatActivity {

    Button go;
    EditText uri;
    VideoView videoPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);

        go = findViewById(R.id.go);
        uri = findViewById(R.id.videouri);
        videoPlayer = (VideoView)findViewById(R.id.videoView);

        final MediaController mediaController= new MediaController(this);
        mediaController.setAnchorView(videoPlayer);



        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri u = Uri.parse(String.valueOf(uri.getText()));

                videoPlayer.setMediaController(mediaController);
                videoPlayer.setVideoURI(u);
                videoPlayer.requestFocus();
                videoPlayer.start();

                videoPlayer.setVideoURI(u);
                videoPlayer.start();
            }
        });

    }
}
